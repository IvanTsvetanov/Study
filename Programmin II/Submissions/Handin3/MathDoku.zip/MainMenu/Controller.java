package MainMenu;

import javafx.scene.Scene;

public class Controller {
}
